<header id="logo">
  <img src="../img/logo.jpg" alt="logo">
  <h1>Guggenheim Bilbao</h1>
</header>
<!-- Menu Horizontal-->
<nav id="menu">
  <ul>
    <li><a href="/">Inicio</a></li>
    <li><a href="">Obras</a>
      <ul>
        <li><a href="?obra=1">24 Cabezas</a></li>
        <li><a href="?obra=2">Villa Borghese</a></li>
        <li><a href="?obra=4">Caja Metafisica</a></li>
        <li><a href="?obra=3">Antropometría azul</a></li>
      </ul>
    </li>
    <li><a href="">Artistas</a></li>
    <li><a href="">Entradas</a></li>
  </ul>
</nav>