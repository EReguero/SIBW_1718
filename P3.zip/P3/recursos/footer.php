<footer>
    <!-- Información de contacto -->
    <div id="contacto">
        <h1> Contacto</h1>
        <p>Dirección: Avenida Abandoibarra, 2 48009 Bilbao</p>
        <p>Teléfono: 944 35 90 00 (Horario oficinas)</p>
        <p>Teléfono: 944 35 90 80 (Horario Museo)</p>   
    </div>
    <!-- Información de copyright-->
    <div id="copyright">
        <p>Copyright © Todos los derechos reservados - Sitio creado por Emilio y Eric</p>
    </div>
</footer>