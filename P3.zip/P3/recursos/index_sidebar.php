<aside id="aux"> 
    <!-- Enlace a la fundación Guggenheim -->
    <a target="_blank" href="https://www.guggenheim.org/foundation">    
        <div id="fundacion">
            <p>Fundación Solomon Guggenheim</p>    
        </div>
    </a>
    <!-- Enlace al Guggenheim New York -->
    <a target="_blank" href="https://www.guggenheim.org/">    
        <div id="NY">
            <p>Guggenheim New York</p>    
        </div>
    </a>
    <!-- Enlace al Guggenheim Venecia -->
    <a target="_blank" href="http://www.guggenheim-venice.it/default.html">    
        <div id="venecia">
            <p>Guggenheim Venecia</p>    
        </div>
    </a>
    <!-- Enlace a informacion adicional de Wikipedia -->
    <a target="_blank" href="https://es.wikipedia.org/wiki/Museo_Guggenheim_Bilbao">    
        <div id="wiki">
            <p>Wikipedia</p>    
        </div>
    </a>
</aside>